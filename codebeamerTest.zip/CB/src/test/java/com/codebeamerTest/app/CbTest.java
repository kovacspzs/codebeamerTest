package com.codebeamerTest.app;

import com.codeborne.selenide.Configuration;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selectors.byXpath;
import static com.codeborne.selenide.Selenide.*;


public class CbTest {

    private static final String PAGE_NAME = "Intland ChildPage";

    private ProjectProperties properties = new ProjectProperties();
    private CommonFunctions commonfunctions = new CommonFunctions();
    private LoginPage login = new LoginPage();
    private StartPage startpage = new StartPage();
    private ProjectPage projectpage = new ProjectPage();


    @Before
    public void setBrowser() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("disable-extensions");
        options.addArguments("incognito");
        Configuration.browser = "chrome";
        Configuration.baseUrl = "http://localhost:8080";
        Configuration.startMaximized = true;
        DesiredCapabilities capabilities = DesiredCapabilities.chrome();
        capabilities.setCapability(ChromeOptions.CAPABILITY, options);
    }


    @Test
    public void codeBeamerTest() {
        //Test step request #1
        open("/");
        login.credentials("pkovacs", "Testpass1234");

       //Test step request #2
        startpage.SelectMenu("Projects");

        //Test step request #3 and #4 #5 #6
        projectpage.CreateProject(properties,"Intland_Software's_Scrum_Template.zip");

        //Test step request #7
        //String projectName = $("#name").getValue();

        //Test step request #8
        //$("#finishButton").click();

        //Test step request #10


        //Test step request extra #1
        $(By.linkText(projectName)).click();
        $(".actionLink").should(appear);
        $(".actionLink", 0).click();

        //Test step request extra #2
        switchTo().frame("inlinedPopupIframe");
        $(By.xpath("//*[@id=\"name\"]")).should(appear);
        $(By.xpath("//*[@id=\"name\"]")).setValue(PAGE_NAME);

        //Test step request extra #3
        $(By.cssSelector("input[type='submit']")).click();
        //Test step request extra #4
        $(".breadcrumbs-summary").$(".generated-link").shouldHave(text(PAGE_NAME));

        //Delete project in order to repeat the entire test
        $("#project_browser_ToolBarItem").click();
        $("#project-list-tab").click();
        $(By.linkText(projectName)).click();
        $("#admin_ToolBarItem").click();
        $(By.cssSelector("input[name='REMOVE']")).click();
        $(byXpath("//button[contains(text(),'Yes')]")).click();
        $(byXpath("//input[@value='Delete Project...']")).click();
        $(byXpath("//button[contains(text(),'Yes')]")).click();
        $(By.tagName("body")).shouldHave(text("has been deleted"));
    }

}

