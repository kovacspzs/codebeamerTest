package com.codebeamerTest.app;

import com.codeborne.selenide.SelenideElement;
import static com.codeborne.selenide.Selenide.$;


public class LoginPage {
    private SelenideElement loginButton = $(".login_button");

    public LoginPage credentials(String username, String password) {
        $("#user").setValue(username);
        $("#password").setValue(password);
        this.loginButton.click();
        return this;
    }
}
