package com.codebeamerTest.app;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import java.io.File;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

public class ProjectPage {
    private SelenideElement createButton = $(By.cssSelector("input[type='submit']"));
    private SelenideElement createNewButton = $("#newProject");
    private SelenideElement finishButton = $("#finishButton");
    private CommonFunctions commonfunctions = new CommonFunctions();
    private static final String FILE_PATH = "src/test/resources/";


    public void CreateProject (ProjectProperties properties, String filename) {
        this.createButton.click();
        this.createNewButton.click();
        File file = $(By.cssSelector("input[type='file']")).uploadFile(new File(FILE_PATH+filename));
        $(".qq-upload-file").shouldHave(text(filename));
        commonfunctions.Submit();
        String projectName = $("#name").getValue();
        properties.setProjectName(projectName);
        this.finishButton.click();
        $("#project_browser_ToolBarItem").click();
        $("#project-list-tab").click();
        Boolean isProjectExists = false;
        if ($("#project-list").getText().equals(properties.getProjectName())){
            isProjectExists = true;
        }

    }
}
